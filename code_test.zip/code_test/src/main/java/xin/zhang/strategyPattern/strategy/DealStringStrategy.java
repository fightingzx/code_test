package xin.zhang.strategyPattern.strategy;

public interface DealStringStrategy {

    String deal(String input);
}
